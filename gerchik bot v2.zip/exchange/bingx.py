import hashlib, hmac, time, logging
from typing import Optional
from urllib.parse import urlencode
import aiohttp

log = logging.getLogger("bingx")
BASE = "https://open-api.bingx.com"


class BingXClient:
    def __init__(self, api_key: str, secret: str):
        self.api_key = api_key
        self.secret  = secret
        self._session: Optional[aiohttp.ClientSession] = None

    async def _sess(self):
        if not self._session or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    def _sign(self, params: dict) -> str:
        params["timestamp"] = int(time.time() * 1000)
        query = urlencode(sorted(params.items()))
        sig = hmac.new(self.secret.encode(), query.encode(), hashlib.sha256).hexdigest()
        return query + "&signature=" + sig

    async def _get(self, path: str, params: dict = None, signed=False) -> dict:
        params = params or {}
        if signed:
            qs  = self._sign(params)
            url = f"{BASE}{path}?{qs}"
        else:
            url = f"{BASE}{path}" + ("?" + urlencode(params) if params else "")
        headers = {"X-BX-APIKEY": self.api_key}
        sess = await self._sess()
        async with sess.get(url, headers=headers) as r:
            data = await r.json()
            if data.get("code") != 0:
                log.error(f"GET {path}: {data}")
            return data

    async def _post(self, path: str, params: dict) -> dict:
        qs  = self._sign(params)
        url = f"{BASE}{path}"
        headers = {"X-BX-APIKEY": self.api_key, "Content-Type": "application/x-www-form-urlencoded"}
        sess = await self._sess()
        async with sess.post(url, data=qs, headers=headers) as r:
            data = await r.json()
            if data.get("code") != 0:
                log.error(f"POST {path}: {data}")
            return data

    # ── РЫНОЧНЫЕ ДАННЫЕ ───────────────────────────────────

    async def get_all_symbols(self) -> list[str]:
        """Все фьючерсные пары BingX"""
        data = await self._get("/openApi/swap/v2/quote/contracts")
        contracts = data.get("data", [])
        return [c["symbol"] for c in contracts if "USDT" in c.get("symbol","")]

    async def get_top_symbols(self, n: int = 0) -> list[str]:
        """Топ N пар по объёму. n=0 → все пары"""
        data = await self._get("/openApi/swap/v2/quote/ticker", {"symbol": ""})
        tickers = data.get("data", [])
        if isinstance(tickers, dict):
            tickers = [tickers]
        sorted_t = sorted(tickers, key=lambda x: float(x.get("quoteVolume", 0)), reverse=True)
        symbols = [t["symbol"] for t in sorted_t if "USDT" in t.get("symbol","")]
        return symbols[:n] if n > 0 else symbols

    async def get_klines(self, symbol: str, interval: str, limit: int = 200) -> list:
        data = await self._get("/openApi/swap/v3/quote/klines", {
            "symbol": symbol, "interval": interval, "limit": limit
        })
        return data.get("data", [])

    async def get_funding_rate(self, symbol: str) -> float:
        data = await self._get("/openApi/swap/v2/quote/premiumIndex", {"symbol": symbol})
        try:
            return float(data["data"]["lastFundingRate"]) * 100
        except Exception:
            return 0.0

    async def get_ticker(self, symbol: str) -> dict:
        data = await self._get("/openApi/swap/v2/quote/ticker", {"symbol": symbol})
        tickers = data.get("data", [])
        if isinstance(tickers, list):
            for t in tickers:
                if t.get("symbol") == symbol:
                    return t
        elif isinstance(tickers, dict):
            return tickers
        return {}

    async def get_balance(self) -> float:
        data = await self._get("/openApi/swap/v2/user/balance", {}, signed=True)
        try:
            for asset in data["data"]["balance"]:
                if asset["asset"] == "USDT":
                    return float(asset["availableMargin"])
        except Exception:
            pass
        return 0.0

    async def get_open_interest(self, symbol: str) -> float:
        data = await self._get("/openApi/swap/v2/quote/openInterest", {"symbol": symbol})
        try:
            return float(data["data"]["openInterest"])
        except Exception:
            return 0.0

    # ── ОРДЕРА ────────────────────────────────────────────

    async def place_order(self, symbol, side, qty, price=0,
                          order_type="MARKET", position_side="LONG",
                          stop_price=0, reduce_only=False) -> dict:
        params = {"symbol": symbol, "side": side,
                  "positionSide": position_side, "type": order_type, "quantity": qty}
        if order_type == "LIMIT" and price:
            params["price"] = price
        if stop_price:
            params["stopPrice"] = stop_price
        if reduce_only:
            params["reduceOnly"] = "true"
        return await self._post("/openApi/swap/v2/trade/order", params)

    async def place_stop_loss(self, symbol, side, qty, stop_price) -> dict:
        pos_side   = "LONG" if side == "BUY" else "SHORT"
        close_side = "SELL" if pos_side == "LONG" else "BUY"
        return await self._post("/openApi/swap/v2/trade/order", {
            "symbol": symbol, "side": close_side, "positionSide": pos_side,
            "type": "STOP_MARKET", "quantity": qty,
            "stopPrice": stop_price, "reduceOnly": "true"
        })

    async def place_take_profit(self, symbol, side, qty, tp_price) -> dict:
        pos_side   = "LONG" if side == "BUY" else "SHORT"
        close_side = "SELL" if pos_side == "LONG" else "BUY"
        return await self._post("/openApi/swap/v2/trade/order", {
            "symbol": symbol, "side": close_side, "positionSide": pos_side,
            "type": "TAKE_PROFIT_MARKET", "quantity": qty,
            "stopPrice": tp_price, "reduceOnly": "true"
        })

    async def cancel_order(self, symbol, order_id) -> dict:
        return await self._post("/openApi/swap/v2/trade/cancelOrder",
                                {"symbol": symbol, "orderId": order_id})

    async def close_position(self, symbol, qty, side) -> dict:
        pos_side   = "LONG" if side == "LONG" else "SHORT"
        close_side = "SELL" if pos_side == "LONG" else "BUY"
        return await self.place_order(symbol, close_side, qty,
                                      position_side=pos_side,
                                      order_type="MARKET", reduce_only=True)

    async def set_leverage(self, symbol, leverage) -> dict:
        r1 = await self._post("/openApi/swap/v2/trade/leverage",
                              {"symbol": symbol, "side": "LONG",  "leverage": leverage})
        r2 = await self._post("/openApi/swap/v2/trade/leverage",
                              {"symbol": symbol, "side": "SHORT", "leverage": leverage})
        return r1

    async def close(self):
        if self._session:
            await self._session.close()