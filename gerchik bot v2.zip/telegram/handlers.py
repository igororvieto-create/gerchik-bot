"""Telegram команды"""
import logging
from datetime import datetime
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from core.config import cfg
from core.state import state

log = logging.getLogger("handlers")
router = Router()

def _auth(msg: Message) -> bool:
    return str(msg.chat.id) == str(cfg.TELEGRAM_CHAT_ID)

@router.message(Command("status"))
async def cmd_status(msg: Message):
    if not _auth(msg): return
    if not state.positions:
        await msg.answer("📭 Нет открытых позиций"); return
    text = "📊 <b>Позиции:</b>\n\n"
    for sym, p in state.positions.items():
        be = "✅ BE" if p.be_moved else "⏳"
        text += (f"<b>{sym}</b> {p.side} {be} | ⭐{p.score}\n"
                 f"  Вход: <code>{p.entry:.4f}</code> | SL: <code>{p.sl:.4f}</code>\n"
                 f"  TP2:  <code>{p.tp2:.4f}</code> | TP3: <code>{p.tp3:.4f}</code>\n\n")
    await msg.answer(text, parse_mode="HTML")

@router.message(Command("balance"))
async def cmd_balance(msg: Message):
    if not _auth(msg): return
    from exchange.bingx import BingXClient
    ex = BingXClient(cfg.BINGX_API_KEY, cfg.BINGX_SECRET)
    bal = await ex.get_balance(); await ex.close()
    state.current_balance = bal
    d = state.day
    wr = round(d.wins/d.trades*100) if d.trades else 0
    await msg.answer(
        f"💰 <b>Баланс: {bal:.2f} USDT</b>\n\n"
        f"День: {d.trades} сделок | WR {wr}% | {'+'if d.pnl_usdt>0 else ''}{d.pnl_usdt:.2f} USDT\n"
        f"Итого: {'+'if state.total_pnl>0 else ''}{state.total_pnl:.2f} USDT\n"
        f"Позиций: {len(state.positions)} / {cfg.MAX_POSITIONS}",
        parse_mode="HTML")

@router.message(Command("pairs"))
async def cmd_pairs(msg: Message):
    if not _auth(msg): return
    n = len(state.pairs)
    preview = " | ".join(state.pairs[:20])
    suffix = f"\n... и ещё {n-20}" if n > 20 else ""
    await msg.answer(f"📋 <b>Пары ({n}):</b>\n{preview}{suffix}", parse_mode="HTML")

@router.message(Command("pause"))
async def cmd_pause(msg: Message):
    if not _auth(msg): return
    state.paused = True
    await msg.answer("⏸ Пауза. /resume — возобновить")

@router.message(Command("resume"))
async def cmd_resume(msg: Message):
    if not _auth(msg): return
    state.paused = False; state.day.paused_until = None
    await msg.answer("▶️ Торговля возобновлена")

@router.message(Command("setmode"))
async def cmd_setmode(msg: Message):
    if not _auth(msg): return
    args = msg.text.split()
    if len(args) < 2 or args[1] not in ("auto","manual"):
        await msg.answer("/setmode auto | /setmode manual"); return
    cfg.MODE = args[1]
    await msg.answer(f"✅ Режим: <code>{cfg.MODE}</code>", parse_mode="HTML")

@router.message(Command("setrisk"))
async def cmd_setrisk(msg: Message):
    if not _auth(msg): return
    args = msg.text.split()
    if len(args) < 2:
        await msg.answer(f"Текущий риск: {cfg.RISK_PER_TRADE}%\n/setrisk 0.5"); return
    try:
        v = float(args[1])
        if not 0.1 <= v <= 3.0:
            raise ValueError
        cfg.RISK_PER_TRADE = v
        await msg.answer(f"✅ Риск: <code>{v}%</code> на сделку", parse_mode="HTML")
    except ValueError:
        await msg.answer("Введи число от 0.1 до 3.0")

@router.message(Command("setlev"))
async def cmd_setlev(msg: Message):
    if not _auth(msg): return
    args = msg.text.split()
    if len(args) < 2:
        await msg.answer(f"Текущее плечо: x{cfg.LEVERAGE}\n/setlev 10"); return
    try:
        v = int(args[1])
        if not 1 <= v <= 50:
            raise ValueError
        cfg.LEVERAGE = v
        await msg.answer(f"✅ Плечо: <code>x{v}</code>", parse_mode="HTML")
    except ValueError:
        await msg.answer("Введи число от 1 до 50")

@router.message(Command("scan"))
async def cmd_scan(msg: Message):
    if not _auth(msg): return
    await msg.answer(f"🔍 Сканирую {len(state.pairs)} пар...")
    from exchange.bingx import BingXClient
    from strategy.scanner import Scanner
    ex = BingXClient(cfg.BINGX_API_KEY, cfg.BINGX_SECRET)
    scanner = Scanner(ex, msg.bot)
    await scanner.scan_all(); await ex.close()

@router.message(Command("update"))
async def cmd_update(msg: Message):
    if not _auth(msg): return
    from exchange.bingx import BingXClient
    from strategy.scanner import Scanner
    ex = BingXClient(cfg.BINGX_API_KEY, cfg.BINGX_SECRET)
    scanner = Scanner(ex, msg.bot)
    await scanner.update_pairs(); await ex.close()

@router.message(Command("closeall"))
async def cmd_closeall(msg: Message):
    if not _auth(msg): return
    if not state.positions:
        await msg.answer("Нет позиций"); return
    from exchange.bingx import BingXClient
    ex = BingXClient(cfg.BINGX_API_KEY, cfg.BINGX_SECRET)
    closed = []
    for sym, p in list(state.positions.items()):
        try:
            await ex.close_position(sym, p.qty, p.side)
            del state.positions[sym]; closed.append(sym)
        except Exception as e:
            log.error(f"closeall {sym}: {e}")
    await ex.close()
    await msg.answer(f"✅ Закрыто: {', '.join(closed) or 'ничего'}")

@router.message(Command("help"))
async def cmd_help(msg: Message):
    if not _auth(msg): return
    await msg.answer(
        "<b>Команды:</b>\n\n"
        "/status — позиции\n"
        "/balance — баланс и статистика\n"
        "/pairs — список пар\n"
        "/scan — запустить скан\n"
        "/update — обновить пары\n"
        "/pause / /resume — пауза\n"
        "/setmode auto|manual — режим\n"
        "/setrisk 1.0 — риск %\n"
        "/setlev 5 — плечо\n"
        "/closeall — закрыть всё\n"
        "/confirm_SYMBOL — подтвердить вход\n"
        "/skip_SYMBOL — пропустить",
        parse_mode="HTML")

@router.message()
async def handle_confirm(msg: Message):
    if not _auth(msg): return
    text = msg.text or ""
    if text.startswith("/confirm_"):
        sym = text.replace("/confirm_","").replace("_","-").upper()
        if sym not in state.pending:
            await msg.answer(f"Сигнал {sym} не найден или истёк"); return
        pend = state.pending[sym]
        if datetime.utcnow() > pend["expires"]:
            state.pending.pop(sym, None)
            await msg.answer(f"⏰ Время истекло: {sym}"); return
        from exchange.bingx import BingXClient
        from strategy.scanner import Scanner
        ex = BingXClient(cfg.BINGX_API_KEY, cfg.BINGX_SECRET)
        scanner = Scanner(ex, msg.bot)
        await scanner._enter(pend["signal"], confirmed=True)
        await ex.close()
    elif text.startswith("/skip_"):
        sym = text.replace("/skip_","").replace("_","-").upper()
        state.pending.pop(sym, None)
        await msg.answer(f"⏭ Пропущен: {sym}")