"""
Стратегия Герчика — Мультитаймфрейм H1 + H4
Логика фильтрации:
  D1  → EMA200 — главный тренд (обязательно)
  H4  → EMA50  — промежуточный тренд + уровни + паттерн (фильтр)
  H1  → паттерн входа + объём (сигнал)
"""
import logging
from dataclasses import dataclass
from typing import Optional
import numpy as np

log = logging.getLogger("strategy")


@dataclass
class Signal:
    symbol:  str
    side:    str
    entry:   float
    sl:      float
    tp1:     float
    tp2:     float
    tp3:     float
    rr:      float
    pattern: str
    tf:      str
    score:   int
    reason:  str


def parse_klines(raw: list) -> dict:
    if not raw:
        return {}
    arr = np.array([[float(c) for c in k[:6]] for k in raw])
    return {"ts": arr[:,0], "open": arr[:,1], "high": arr[:,2],
            "low": arr[:,3], "close": arr[:,4], "volume": arr[:,5]}


def ema(values: np.ndarray, period: int) -> np.ndarray:
    result = np.zeros_like(values)
    k = 2 / (period + 1)
    result[0] = values[0]
    for i in range(1, len(values)):
        result[i] = values[i] * k + result[i-1] * (1 - k)
    return result


def vol_ma(volumes: np.ndarray, period: int = 20) -> np.ndarray:
    result = np.zeros_like(volumes)
    for i in range(period - 1, len(volumes)):
        result[i] = volumes[i-period+1:i+1].mean()
    return result


def find_levels(highs: np.ndarray, lows: np.ndarray, lookback: int = 60) -> dict:
    rh, rl = highs[-lookback:], lows[-lookback:]
    res, sup = [], []
    for i in range(2, len(rh)-2):
        if rh[i] > rh[i-1] and rh[i] > rh[i-2] and rh[i] > rh[i+1] and rh[i] > rh[i+2]:
            res.append(float(rh[i]))
    for i in range(2, len(rl)-2):
        if rl[i] < rl[i-1] and rl[i] < rl[i-2] and rl[i] < rl[i+1] and rl[i] < rl[i+2]:
            sup.append(float(rl[i]))
    return {"resistance": res, "support": sup}


def near_level(price: float, levels: list, tol_pct: float = 0.4) -> tuple:
    for lvl in levels:
        if abs(price - lvl) / price * 100 <= tol_pct:
            return True, lvl
    return False, 0.0


def level_touches(level: float, highs, lows, tol_pct=0.25) -> int:
    t = level * tol_pct / 100
    return sum(1 for h, l in zip(highs, lows) if abs(h-level)<=t or abs(l-level)<=t)


# ── Паттерны ──────────────────────────────────────────────────────────

def hammer(o, h, l, c):
    body = abs(c - o); full = h - l
    if full == 0: return False
    low_sh = min(o,c) - l; up_sh = h - max(o,c)
    return body/full <= 0.35 and low_sh >= body*2 and up_sh <= body*0.5 and c > o

def shooting_star(o, h, l, c):
    body = abs(c - o); full = h - l
    if full == 0: return False
    up_sh = h - max(o,c); low_sh = min(o,c) - l
    return body/full <= 0.35 and up_sh >= body*2 and low_sh <= body*0.5 and c < o

def bull_engulf(o1, c1, o2, c2):
    return c1 < o1 and c2 > o2 and o2 < c1 and c2 > o1

def bear_engulf(o1, c1, o2, c2):
    return c1 > o1 and c2 < o2 and o2 > c1 and c2 < o1

def bull_pin(o, h, l, c):
    body = abs(c-o); full = h-l
    if full == 0: return False
    return (min(o,c)-l) > full*0.6 and body < full*0.25

def bear_pin(o, h, l, c):
    body = abs(c-o); full = h-l
    if full == 0: return False
    return (h-max(o,c)) > full*0.6 and body < full*0.25


def detect_pattern(candles: dict, idx: int = -1) -> tuple:
    i  = idx if idx >= 0 else len(candles["open"]) + idx
    o  = candles["open"][i];  h = candles["high"][i]
    l  = candles["low"][i];   c = candles["close"][i]
    o1 = candles["open"][i-1]; c1 = candles["close"][i-1]
    if hammer(o, h, l, c):          return "Молот", "LONG"
    if bull_pin(o, h, l, c):        return "Пин-бар (бычий)", "LONG"
    if bull_engulf(o1, c1, o, c):   return "Бычье поглощение", "LONG"
    if shooting_star(o, h, l, c):   return "Падающая звезда", "SHORT"
    if bear_pin(o, h, l, c):        return "Пин-бар (медвежий)", "SHORT"
    if bear_engulf(o1, c1, o, c):   return "Медвежье поглощение", "SHORT"
    return "", ""


# ── ГЛАВНАЯ ФУНКЦИЯ ───────────────────────────────────────────────────

def analyze(symbol: str, d1: dict, h4: dict, h1: dict,
            funding: float, cfg) -> Optional[Signal]:

    if not d1 or not h4 or not h1:
        return None
    if len(d1["close"]) < cfg.TREND_EMA_D1:
        return None
    if len(h4["close"]) < cfg.TREND_EMA_H4:
        return None

    # ── 1. ТРЕНД D1 — EMA200 (обязательный фильтр) ─────────────
    ema200 = ema(d1["close"], cfg.TREND_EMA_D1)
    d1_up  = d1["close"][-1] > ema200[-1]
    d1_dn  = d1["close"][-1] < ema200[-1]
    if not d1_up and not d1_dn:
        return None
    trend = "LONG" if d1_up else "SHORT"

    # ── 2. ТРЕНД H4 — EMA50 (подтверждение) ────────────────────
    ema50_h4 = ema(h4["close"], cfg.TREND_EMA_H4)
    h4_up    = h4["close"][-1] > ema50_h4[-1]
    h4_dn    = h4["close"][-1] < ema50_h4[-1]

    # H4 должен совпадать с D1
    if trend == "LONG" and not h4_up:
        log.debug(f"{symbol}: H4 против D1 тренда, пропуск")
        return None
    if trend == "SHORT" and not h4_dn:
        log.debug(f"{symbol}: H4 против D1 тренда, пропуск")
        return None

    price = h1["close"][-1]

    # ── 3. УРОВНИ (ищем на H4 — более значимые) ─────────────────
    levels_h4 = find_levels(h4["high"], h4["low"], lookback=80)
    if trend == "LONG":
        near, level = near_level(price, levels_h4["support"], tol_pct=0.5)
    else:
        near, level = near_level(price, levels_h4["resistance"], tol_pct=0.5)

    if not near:
        # Попробуем уровни H1
        levels_h1 = find_levels(h1["high"], h1["low"], lookback=50)
        if trend == "LONG":
            near, level = near_level(price, levels_h1["support"], tol_pct=0.3)
        else:
            near, level = near_level(price, levels_h1["resistance"], tol_pct=0.3)

    if not near:
        log.debug(f"{symbol}: нет уровня рядом, пропуск")
        return None

    touches = level_touches(level, h4["high"][-80:], h4["low"][-80:])
    if touches > 3:
        log.debug(f"{symbol}: уровень затёрт ({touches} касаний)")
        return None

    # ── 4. ПАТТЕРН H1 ────────────────────────────────────────────
    pattern_name, pattern_side = detect_pattern(h1)
    if not pattern_name or pattern_side != trend:
        log.debug(f"{symbol}: паттерн не найден или против тренда")
        return None

    # ── 5. ПАТТЕРН H4 (дополнительный фильтр) ───────────────────
    h4_pattern, h4_side = detect_pattern(h4)
    h4_confirms = h4_pattern != "" and h4_side == trend

    # ── 6. ОБЪЁМ H1 ──────────────────────────────────────────────
    vm    = vol_ma(h1["volume"], cfg.VOLUME_MA_PERIOD)
    v_rat = h1["volume"][-1] / vm[-1] if vm[-1] > 0 else 0
    if v_rat < cfg.VOLUME_MULT:
        log.debug(f"{symbol}: объём {v_rat:.2f}× < {cfg.VOLUME_MULT}×")
        return None

    # ── 7. FUNDING ───────────────────────────────────────────────
    if trend == "LONG"  and funding > cfg.FUNDING_MAX_LONG:
        return None
    if trend == "SHORT" and funding < cfg.FUNDING_MAX_SHORT:
        return None

    # ── 8. SL / TP ───────────────────────────────────────────────
    buf   = price * cfg.SL_BUFFER_PCT / 100
    sl    = (h1["low"][-1]  - buf) if trend == "LONG" else (h1["high"][-1] + buf)
    sl_d  = abs(price - sl)
    if sl_d <= 0:
        return None

    tp1 = price + sl_d*cfg.TP1_RR if trend=="LONG" else price - sl_d*cfg.TP1_RR
    tp2 = price + sl_d*cfg.TP2_RR if trend=="LONG" else price - sl_d*cfg.TP2_RR
    tp3 = price + sl_d*cfg.TP3_RR if trend=="LONG" else price - sl_d*cfg.TP3_RR
    rr  = cfg.TP2_RR

    if rr < cfg.MIN_RR:
        return None

    # ── SCORE ────────────────────────────────────────────────────
    score = 55
    score += 10 if v_rat >= 2.0 else 5
    score += 10 if touches <= 2 else 3
    score += 10 if h4_confirms else 0
    score += 10 if abs(funding) < 0.02 else 5
    score += 5  if rr >= 3.0 else 0
    score = min(score, 100)

    h4_tag = f"H4: {h4_pattern} ✅" if h4_confirms else "H4: нет паттерна"

    reason = (
        f"📊 <b>{symbol}</b> | {trend}\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🕯 H1 паттерн: <b>{pattern_name}</b>\n"
        f"🕯 {h4_tag}\n"
        f"📈 D1 тренд: {'🟢 Бычий' if d1_up else '🔴 Медвежий'}\n"
        f"📈 H4 тренд: {'🟢' if h4_up else '🔴'} EMA50\n"
        f"🎯 Уровень H4: <code>{level:.4f}</code> ({touches} кас.)\n"
        f"📦 Объём: <code>{v_rat:.2f}×</code> MA(20)\n"
        f"💸 Funding: <code>{funding:.4f}%</code>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🟡 Вход:  <code>{price:.4f}</code>\n"
        f"🔴 SL:    <code>{sl:.4f}</code>\n"
        f"🟢 TP1:   <code>{tp1:.4f}</code> (1R — BE)\n"
        f"🟢 TP2:   <code>{tp2:.4f}</code> (2R — 60%)\n"
        f"🟢 TP3:   <code>{tp3:.4f}</code> (3R — всё)\n"
        f"⚡ R/R:   <code>1:{rr:.1f}</code>\n"
        f"⭐ Score: <code>{score}/100</code>"
    )

    return Signal(symbol=symbol, side=trend, entry=price,
                  sl=sl, tp1=tp1, tp2=tp2, tp3=tp3,
                  rr=rr, pattern=pattern_name, tf="H1+H4",
                  score=score, reason=reason)