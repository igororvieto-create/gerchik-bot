# ГЕРЧИК БОТ v2 — BingX Futures

## Параметры
- Пары: **все BingX фьючерсы** (авто-обновление каждый час)
- Таймфрейм: **H1 + H4 + D1** (мультитаймфрейм)
- Режим: **полный автопилот**

## Логика входа
1. D1 EMA200 → главный тренд
2. H4 EMA50 → подтверждение тренда
3. H4 уровень → поддержка/сопротивление
4. H1 паттерн → молот/поглощение/пин-бар
5. H1 объём → > 1.5× MA(20)
6. Funding rate → фильтр перегрева

## Управление позицией
- TP1 (1R) → стоп в безубыток
- TP2 (2R) → закрыть 60%
- TP3 (3R) → закрыть остаток
- 2 стопа подряд → пауза 30 мин

## Railway — переменные среды
```
TELEGRAM_TOKEN     = токен от @BotFather
TELEGRAM_CHAT_ID   = твой chat_id
BINGX_API_KEY      = API ключ BingX
BINGX_SECRET       = секрет BingX
BOT_MODE           = auto
RISK_PER_TRADE     = 1.0
MAX_POSITIONS      = 5
LEVERAGE           = 5
MIN_SCORE          = 65
BLACKLIST          = LUNA-USDT,FTT-USDT,LUNC-USDT
SCAN_H1_INTERVAL_MIN = 5
SCAN_BATCH_SIZE    = 10
```

## Деплой
```bash
git init && git add . && git commit -m "gerchik bot v2"
git remote add origin https://github.com/ТВО_НИК/gerchik-bot.git
git push -u origin main
```
Railway → New Project → Deploy from GitHub

## Команды
| Команда | Действие |
|---------|----------|
| /status | Открытые позиции |
| /balance | Баланс и статистика |
| /pairs | Список пар |
| /scan | Ручной скан |
| /pause / /resume | Пауза |
| /setmode auto\|manual | Режим |
| /setrisk 1.0 | Риск % |
| /setlev 5 | Плечо |
| /closeall | Закрыть всё |
| /help | Все команды |
