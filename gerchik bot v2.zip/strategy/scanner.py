"""
Сканер — все пары BingX, мультитаймфрейм H1+H4, автопилот
"""
import asyncio, logging
from datetime import datetime, timedelta
from aiogram import Bot
from core.config import cfg
from core.state import Position, state
from exchange.bingx import BingXClient
from strategy.gerchik import Signal, analyze, parse_klines

log = logging.getLogger("scanner")


class Scanner:
    def __init__(self, exchange: BingXClient, bot: Bot):
        self.ex  = exchange
        self.bot = bot

    async def _notify(self, text: str):
        try:
            await self.bot.send_message(cfg.TELEGRAM_CHAT_ID, text, parse_mode="HTML")
        except Exception as e:
            log.error(f"TG error: {e}")

    # ── ОБНОВЛЕНИЕ ПАР ───────────────────────────────────────────
    async def update_pairs(self):
        try:
            if cfg.WHITELIST:
                state.pairs = cfg.WHITELIST
                log.info(f"Пары из WHITELIST: {len(state.pairs)}")
                return

            # Все пары BingX фьючерсов
            symbols = await self.ex.get_top_symbols(cfg.TOP_N_PAIRS)
            state.pairs = [s for s in symbols if s not in cfg.BLACKLIST]
            log.info(f"Пары обновлены: {len(state.pairs)} шт.")
            await self._notify(
                f"🔄 Пары обновлены: <b>{len(state.pairs)}</b> шт.\n"
                f"Режим: <code>{cfg.MODE}</code> | ТФ: H1+H4+D1"
            )
        except Exception as e:
            log.error(f"update_pairs: {e}")

    # ── СКАНИРОВАНИЕ H1 (каждые 5 мин) ───────────────────────────
    async def scan_all(self):
        if not state.pairs:
            await self.update_pairs()

        can, reason = state.can_trade(cfg.MAX_DAILY_LOSS, cfg.MAX_POSITIONS, cfg.MAX_DAILY_TRADES)
        if not can:
            log.info(f"Пропуск скана: {reason}")
            return

        log.info(f"Сканирую {len(state.pairs)} пар (H1+H4)...")
        signals = []

        # Батчевый запрос — не перегружаем API
        for i in range(0, len(state.pairs), cfg.SCAN_BATCH_SIZE):
            batch = state.pairs[i:i+cfg.SCAN_BATCH_SIZE]
            tasks = [self._analyze(sym) for sym in batch
                     if sym not in state.positions and sym not in state.pending]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for r in results:
                if isinstance(r, Signal):
                    signals.append(r)
            if i + cfg.SCAN_BATCH_SIZE < len(state.pairs):
                await asyncio.sleep(cfg.SCAN_BATCH_DELAY)

        if not signals:
            log.info("Сигналов нет")
            return

        signals.sort(key=lambda s: s.score, reverse=True)
        log.info(f"Сигналов найдено: {len(signals)}")

        for sig in signals:
            can, _ = state.can_trade(cfg.MAX_DAILY_LOSS, cfg.MAX_POSITIONS, cfg.MAX_DAILY_TRADES)
            if not can:
                break
            if sig.score < cfg.MIN_SCORE:
                continue
            await self._handle(sig)

    async def _analyze(self, symbol: str):
        try:
            d1_raw  = await self.ex.get_klines(symbol, cfg.TREND_TF, limit=250)
            h4_raw  = await self.ex.get_klines(symbol, cfg.H4_TF,    limit=150)
            h1_raw  = await self.ex.get_klines(symbol, cfg.SIGNAL_TF, limit=100)
            funding = await self.ex.get_funding_rate(symbol)
            return analyze(symbol, parse_klines(d1_raw), parse_klines(h4_raw),
                           parse_klines(h1_raw), funding, cfg)
        except Exception as e:
            log.error(f"analyze {symbol}: {e}")
            return None

    # ── ОБРАБОТКА СИГНАЛА ─────────────────────────────────────────
    async def _handle(self, sig: Signal):
        if cfg.MODE == "auto":
            await self._enter(sig)
        else:
            state.pending[sig.symbol] = {
                "signal":  sig,
                "expires": datetime.utcnow() + timedelta(seconds=cfg.CONFIRM_TIMEOUT_SEC)
            }
            await self._notify(
                f"🔔 <b>СЕТАП</b>\n\n{sig.reason}\n\n"
                f"⏳ {cfg.CONFIRM_TIMEOUT_SEC//60} мин:\n"
                f"/confirm_{sig.symbol.replace('-','_')} — войти\n"
                f"/skip_{sig.symbol.replace('-','_')} — пропустить"
            )

    # ── ВХОД В СДЕЛКУ ─────────────────────────────────────────────
    async def _enter(self, sig: Signal, confirmed=False):
        log.info(f"Вхожу: {sig.symbol} {sig.side} score={sig.score}")
        try:
            balance = await self.ex.get_balance()
            if balance <= 0:
                await self._notify("❌ Баланс = 0")
                return
            state.current_balance = balance

            risk_usdt = balance * cfg.RISK_PER_TRADE / 100
            sl_pct    = abs(sig.entry - sig.sl) / sig.entry
            if sl_pct == 0:
                return
            pos_size = risk_usdt / sl_pct
            qty      = round(pos_size / sig.entry, 3)
            if qty <= 0:
                return

            await self.ex.set_leverage(sig.symbol, cfg.LEVERAGE)

            side     = "BUY" if sig.side == "LONG" else "SELL"
            pos_side = sig.side
            order    = await self.ex.place_order(sig.symbol, side, qty, position_side=pos_side)
            order_id = str(order.get("data", {}).get("orderId", ""))

            sl_order = await self.ex.place_stop_loss(sig.symbol, side, qty, sig.sl)
            sl_id    = str(sl_order.get("data", {}).get("orderId", ""))

            tp_order = await self.ex.place_take_profit(sig.symbol, side, qty, sig.tp3)
            tp_id    = str(tp_order.get("data", {}).get("orderId", ""))

            pos = Position(
                symbol=sig.symbol, side=sig.side,
                entry=sig.entry, sl=sig.sl,
                tp1=sig.tp1, tp2=sig.tp2, tp3=sig.tp3,
                qty=qty, risk_usdt=risk_usdt,
                order_id=order_id, sl_order_id=sl_id, tp_order_id=tp_id,
                pattern=sig.pattern, tf=sig.tf, rr=sig.rr, score=sig.score
            )
            state.positions[sig.symbol] = pos
            state.day.trades += 1
            state.pending.pop(sig.symbol, None)

            tag = "🤖 АВТО" if not confirmed else "✅ ПОДТВЕРЖДЕНО"
            await self._notify(
                f"{tag} <b>ВХОД</b>\n\n"
                f"📊 {sig.symbol} {sig.side} | ⭐{sig.score}/100\n"
                f"🕯 {sig.pattern} (H1+H4)\n"
                f"🟡 Вход: <code>{sig.entry:.4f}</code>\n"
                f"🔴 SL:   <code>{sig.sl:.4f}</code>\n"
                f"🟢 TP2:  <code>{sig.tp2:.4f}</code> (2R)\n"
                f"🟢 TP3:  <code>{sig.tp3:.4f}</code> (3R)\n"
                f"💰 Риск: <code>{risk_usdt:.2f} USDT</code> | {cfg.RISK_PER_TRADE}%\n"
                f"📦 Qty:  <code>{qty}</code> | x{cfg.LEVERAGE}"
            )
        except Exception as e:
            log.error(f"enter {sig.symbol}: {e}")
            await self._notify(f"❌ Ошибка входа {sig.symbol}: {e}")

    # ── МОНИТОРИНГ ПОЗИЦИЙ (каждые 30 сек) ───────────────────────
    async def monitor_positions(self):
        for symbol, pos in list(state.positions.items()):
            try:
                ticker = await self.ex.get_ticker(symbol)
                if not ticker:
                    continue
                price = float(ticker.get("lastPrice", pos.entry))

                # TP1 → безубыток
                if not pos.be_moved:
                    tp1_hit = (pos.side=="LONG" and price>=pos.tp1) or                               (pos.side=="SHORT" and price<=pos.tp1)
                    if tp1_hit:
                        await self._move_be(pos)

                # TP2 → фиксация 60%
                if pos.be_moved and not pos.tp2_hit:
                    tp2_hit = (pos.side=="LONG" and price>=pos.tp2) or                               (pos.side=="SHORT" and price<=pos.tp2)
                    if tp2_hit:
                        await self._partial_close(pos, cfg.TP2_CLOSE_PCT, "TP2")

                await self._check_closed(pos, price)
            except Exception as e:
                log.error(f"monitor {symbol}: {e}")

    async def _move_be(self, pos: Position):
        try:
            if pos.sl_order_id:
                await self.ex.cancel_order(pos.symbol, pos.sl_order_id)
            side = "BUY" if pos.side=="LONG" else "SELL"
            r = await self.ex.place_stop_loss(pos.symbol, side, pos.qty, pos.entry)
            pos.sl_order_id = str(r.get("data",{}).get("orderId",""))
            pos.sl = pos.entry
            pos.be_moved = True
            await self._notify(
                f"🔄 <b>БЕЗУБЫТОК</b> | {pos.symbol}\n"
                f"TP1 достигнут → SL → <code>{pos.entry:.4f}</code>"
            )
        except Exception as e:
            log.error(f"move_be {pos.symbol}: {e}")

    async def _partial_close(self, pos: Position, pct: float, label: str):
        try:
            qty = round(pos.qty * pct, 3)
            if qty <= 0:
                return
            await self.ex.close_position(pos.symbol, qty, pos.side)
            pos.qty    -= qty
            pos.tp2_hit = True
            profit_est  = qty * abs(pos.tp2 - pos.entry)
            await self._notify(
                f"✅ <b>{label}</b> | {pos.symbol}\n"
                f"Закрыто {int(pct*100)}% | ~{profit_est:.2f} USDT\n"
                f"Остаток трейлится до TP3"
            )
        except Exception as e:
            log.error(f"partial_close {pos.symbol}: {e}")

    async def _check_closed(self, pos: Position, price: float):
        sl_hit  = (pos.side=="LONG"  and price<=pos.sl) or (pos.side=="SHORT" and price>=pos.sl)
        tp3_hit = (pos.side=="LONG"  and price>=pos.tp3) or (pos.side=="SHORT" and price<=pos.tp3)
        if not sl_hit and not tp3_hit:
            return

        pnl = (price-pos.entry)*pos.qty if pos.side=="LONG" else (pos.entry-price)*pos.qty
        state.total_pnl    += pnl
        state.day.pnl_usdt += pnl

        if pnl > 0:
            state.day.wins += 1
            state.day.loss_streak = 0
        else:
            state.day.losses    += 1
            state.day.loss_streak += 1
            state.day.paused_until = datetime.utcnow() + timedelta(minutes=cfg.PAUSE_AFTER_LOSS_MIN)

        del state.positions[pos.symbol]
        result = "✅ WIN" if pnl > 0 else "❌ LOSS"
        label  = "TP3 🎯" if tp3_hit else "SL 🛑"
        await self._notify(
            f"{result} | <b>{pos.symbol}</b> {pos.side}\n\n"
            f"Закрыто по {label}\n"
            f"Цена: <code>{price:.4f}</code>\n"
            f"PnL:  <code>{'+'if pnl>0 else ''}{pnl:.2f} USDT</code>\n"
            f"День: <code>{'+'if state.day.pnl_usdt>0 else ''}{state.day.pnl_usdt:.2f} USDT</code>"
        )

    # ── ДНЕВНОЙ ОТЧЁТ ─────────────────────────────────────────────
    async def daily_report(self):
        d  = state.day
        wr = round(d.wins/d.trades*100) if d.trades else 0
        await self._notify(
            f"📋 <b>Дневной отчёт</b> — {d.date}\n\n"
            f"Сделок:  <code>{d.trades}</code>\n"
            f"Win/Loss: <code>{d.wins}/{d.losses}</code>\n"
            f"Winrate:  <code>{wr}%</code>\n"
            f"PnL день: <code>{'+'if d.pnl_usdt>0 else ''}{d.pnl_usdt:.2f} USDT</code>\n"
            f"PnL итого: <code>{'+'if state.total_pnl>0 else ''}{state.total_pnl:.2f} USDT</code>"
        )